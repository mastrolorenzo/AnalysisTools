#!/usr/bin/env bash

pip install --user cms_figure
