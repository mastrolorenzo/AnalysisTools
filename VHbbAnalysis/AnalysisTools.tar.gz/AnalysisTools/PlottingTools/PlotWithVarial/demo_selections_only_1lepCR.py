from main_selections import *

the_category_dict = {
#   region block     categories       sel.  histograms
    'CR_1Lepton':   [cats_CR_1Lepton, [],   main_plotvariables.vars_1lepCR_only],
#                                                          notice "_only" ^^^^^
#                                                          these are just the ones
#                                                          from the 1-lep CR, without
#                                                          variables_used_in_selections
}
