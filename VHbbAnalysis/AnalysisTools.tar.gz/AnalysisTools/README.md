AnalysisTools
=============

source env.sh

make

cd VHbbAnalysis

python RunAnalysis.py vhbb_config.txt
